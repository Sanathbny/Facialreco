# Facial-Expression-Detection

This is the code for [this video](https://youtu.be/VRcWW8q8uP8) by Ritesh on YouTube.

Facial Expression or Facial Emotion Detector can be used to know whether a person is sad, happy, angry and so on only through his/her face. This Repository can be used to carry out such a task. It uses your WebCamera and then identifies your expression in Real Time. Yeah in real-time! It also works on any image.
